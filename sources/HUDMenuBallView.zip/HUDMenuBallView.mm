//
//  HUDMenuBallView.m
//  YuanBao
//
//  Created by 特特 on 2025/4/10.
//  Copyright © 2025 Mr_Laote. All rights reserved.
//

#import "HUDMenuBallView.h"

@implementation HUDMenuBallView {
    UIImageView *_imageView;
    CGAffineTransform _originalTransform;
    CGPoint _initialTouchLocation;
    CGPoint _initialCenter;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.4];
        self.layer.cornerRadius = frame.size.width / 2;
        self.layer.masksToBounds = YES;
        self.userInteractionEnabled = YES;
        _originalTransform = CGAffineTransformIdentity;
        
        _imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        _imageView.layer.cornerRadius = frame.size.width / 2;
        _imageView.layer.masksToBounds = YES;
        [self addSubview:_imageView];
        [self setupImage];
        
        // 敲击3次悬浮球隐藏悬浮球
        UITapGestureRecognizer *tripleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideBallView)];
        tripleTap.numberOfTapsRequired = 3;
        tripleTap.delegate = self;
        [self addGestureRecognizer:tripleTap];
    }
    return self;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    return YES;
}

- (void)setupImage {
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSData *imageData = [[NSData alloc] initWithBase64EncodedString:ImageTX options:NSDataBase64DecodingIgnoreUnknownCharacters];
        UIImage *decodedImage = [UIImage imageWithData:imageData];
        CGSize targetSize = CGSizeMake(60, 60);
        UIGraphicsBeginImageContextWithOptions(targetSize, NO, 0.0);
        CGRect imageRect = CGRectMake(0, 0, targetSize.width, targetSize.height);
        [decodedImage drawInRect:imageRect];
        UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        dispatch_async(dispatch_get_main_queue(), ^{
            self->_imageView.image = scaledImage;
        });
    });
}

// 隐藏悬浮球
- (void)hideBallView {
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0.0;
    } completion:^(BOOL finished) {
        self.hidden = YES;
        self.alpha = 1.0;
    }];
}

// 显示悬浮球
- (void)showBallView {
    self.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1.0;
    }];
}

- (void)updateOrientation:(UIInterfaceOrientation)orientation {
    if (_currentOrientation == orientation) return;
    _currentOrientation = orientation;
    
    CGAffineTransform transform;
    switch (orientation) {
        case UIInterfaceOrientationLandscapeLeft:
            transform = CGAffineTransformMakeRotation(-M_PI_2);
            break;
        case UIInterfaceOrientationLandscapeRight:
            transform = CGAffineTransformMakeRotation(M_PI_2);
            break;
        case UIInterfaceOrientationPortraitUpsideDown:
            transform = CGAffineTransformMakeRotation(M_PI);
            break;
        default:
            transform = CGAffineTransformIdentity;
            break;
    }
    
    [UIView animateWithDuration:0.3 animations:^{
        self.transform = transform;
    }];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.isDragging = YES;
    UITouch *touch = [touches anyObject];
    _initialTouchLocation = [touch locationInView:self.superview];
    _initialCenter = self.center;
    [self.superview bringSubviewToFront:self];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (!self.isDragging) return;
    
    UITouch *touch = [touches anyObject];
    CGPoint currentLocation = [touch locationInView:self.superview];
    CGFloat deltaX = currentLocation.x - _initialTouchLocation.x;
    CGFloat deltaY = currentLocation.y - _initialTouchLocation.y;
    CGPoint newCenter = CGPointMake(_initialCenter.x + deltaX, _initialCenter.y + deltaY);
    CGFloat ballRadius = self.bounds.size.width/2;
    CGSize superSize = self.superview.bounds.size;
    
    UIEdgeInsets safeArea = UIEdgeInsetsZero;
    if (@available(iOS 11.0, *)) {
        safeArea = self.superview.safeAreaInsets;
    }
    
    CGFloat minX = safeArea.left + ballRadius;
    CGFloat maxX = superSize.width - safeArea.right - ballRadius;
    CGFloat minY = safeArea.top + ballRadius;
    CGFloat maxY = superSize.height - safeArea.bottom - ballRadius;
    newCenter.x = MAX(minX, MIN(newCenter.x, maxX));
    newCenter.y = MAX(minY, MIN(newCenter.y, maxY));
    self.center = newCenter;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.isDragging = NO;
    [self checkPositionStability];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.isDragging = NO;
    [self checkPositionStability];
}

- (void)checkPositionStability {
    CGFloat ballRadius = self.bounds.size.width/2;
    CGSize superSize = self.superview.bounds.size;
    
    UIEdgeInsets safeArea = UIEdgeInsetsZero;
    if (@available(iOS 11.0, *)) {
        safeArea = self.superview.safeAreaInsets;
    }
    
    CGFloat minX = safeArea.left + ballRadius;
    CGFloat maxX = superSize.width - safeArea.right - ballRadius;
    CGFloat minY = safeArea.top + ballRadius;
    CGFloat maxY = superSize.height - safeArea.bottom - ballRadius;
    
    CGPoint newCenter = self.center;
    newCenter.x = MAX(minX, MIN(newCenter.x, maxX));
    newCenter.y = MAX(minY, MIN(newCenter.y, maxY));
    
    if (!CGPointEqualToPoint(newCenter, self.center)) {
        [UIView animateWithDuration:0.2 animations:^{
            self.center = newCenter;
        }];
    }
}

@end
