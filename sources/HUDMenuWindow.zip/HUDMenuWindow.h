//
//  HUDMenuWindow.h
//  YuanBao
//
//  Created by 特特 on 2025/4/8.
//  Copyright © 2025 Mr_Laote. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HUDMenuBallView.h"

NS_ASSUME_NONNULL_BEGIN

@interface HUDMenuWindow : UIWindow

@property (nonatomic, strong) HUDMenuBallView *ballView;

- (void)showBallView:(BOOL)show;
- (void)adjustBallPositionForRotation;

@end

NS_ASSUME_NONNULL_END
