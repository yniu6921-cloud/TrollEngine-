//
//  HUDMenuWindow.m
//  YuanBao
//
//  Created by 特特 on 2025/4/8.
//  Copyright © 2025 Mr_Laote. All rights reserved.
//

// MARK: 菜单图层（触摸等···）

#import "HUDMenuWindow.h"
#import "HUDMenuRootViewController.h"
#import "HUDMenuBallView.h"
#import <MetalKit/MetalKit.h>

@implementation HUDMenuWindow

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // 悬浮球
        _ballView = [[HUDMenuBallView alloc] initWithFrame:CGRectMake(self.bounds.size.width / 2, 150, 60, 60)];
        [self addSubview:_ballView];
        
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (!self.ballView.isDragging) {
        [self adjustBallPositionForRotation];
    }
}

- (void)adjustBallPositionForRotation {
    if (self.ballView.isDragging) return;
    
    CGSize screenSize = self.bounds.size;
    CGFloat ballRadius = self.ballView.bounds.size.width/2;
    
    UIEdgeInsets safeArea = UIEdgeInsetsZero;
    if (@available(iOS 11.0, *)) {
        safeArea = self.safeAreaInsets;
    }
    
    CGFloat edgeThreshold = 5.0;
    CGFloat minX = safeArea.left + ballRadius + edgeThreshold;
    CGFloat maxX = screenSize.width - safeArea.right - ballRadius - edgeThreshold;
    CGFloat minY = safeArea.top + ballRadius + edgeThreshold;
    CGFloat maxY = screenSize.height - safeArea.bottom - ballRadius - edgeThreshold;
    
    CGFloat newX = MAX(minX, MIN(self.ballView.center.x, maxX));
    CGFloat newY = MAX(minY, MIN(self.ballView.center.y, maxY));
    
    if (newX != self.ballView.center.x || newY != self.ballView.center.y) {
        [UIView animateWithDuration:0.3 animations:^{
            self.ballView.center = CGPointMake(newX, newY);
        }];
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
}

- (void)setCenterWithDeltaX:(CGFloat)deltaX deltaY:(CGFloat)deltaY {
    CGFloat halfWidth = self.bounds.size.width/2;
    CGFloat halfHeight = self.bounds.size.height/2;
    CGSize superSize = self.superview.bounds.size;
    UIEdgeInsets safeArea = UIEdgeInsetsZero;
    if (@available(iOS 11.0, *)) {
        safeArea = self.window.safeAreaInsets;
    }
    CGFloat minX = safeArea.left + halfWidth;
    CGFloat maxX = superSize.width - safeArea.right - halfWidth;
    CGFloat minY = safeArea.top + halfHeight;
    CGFloat maxY = superSize.height - safeArea.bottom - halfHeight;
    CGFloat newX = MAX(minX, MIN(self.center.x + deltaX, maxX));
    CGFloat newY = MAX(minY, MIN(self.center.y + deltaY, maxY));
    self.center = CGPointMake(newX, newY);
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    CGPoint ballPoint = [self convertPoint:point toView:self.ballView];
    if (!self.ballView.hidden && [self.ballView pointInside:ballPoint withEvent:event]) {
        return [self.ballView hitTest:ballPoint withEvent:event];
    }
    
    return [super hitTest:point withEvent:event];
}

// 如需显示悬浮球 [menuWindow showBallView:YES];
- (void)showBallView:(BOOL)show {
    if (show) {
        [self.ballView showBallView];
    } else {
        [self.ballView hideBallView];
    }
}

+ (BOOL)_isSystemWindow { return YES; }
- (BOOL)_isWindowServerHostingManaged { return NO; }
- (BOOL)_ignoresHitTest { return [HUDMenuRootViewController passthroughMode]; }
- (BOOL)_isSecure { return YES; }
- (BOOL)_shouldCreateContextAsSecure { return YES; }

@end
