#import "HUDMenuRootViewController.h"
#import <notify.h>
#import <objc/runtime.h>

// MARK: info
#import "YuanBao-Swift.h"

#if !NO_TROLL
#import "FBSOrientationUpdate.h"
#import "FBSOrientationObserver.h"
#import "UIApplication+Private.h"
#import "LSApplicationProxy.h"
#import "LSApplicationWorkspace.h"
#import "SpringBoardServices.h"
#import "HUDMenuWindow.h"

#define NOTIFY_UI_LOCKSTATE    "com.apple.springboard.lockstate"
#define NOTIFY_LS_APP_CHANGED  "com.apple.LaunchServices.ApplicationsChanged"

static void LaunchServicesApplicationStateChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    BOOL isAppInstalled = NO;
    for (LSApplicationProxy *app in [[objc_getClass("LSApplicationWorkspace") defaultWorkspace] allApplications]) {
        if ([app.applicationIdentifier isEqualToString:@"com.Laote.YuanBao"]) {
            isAppInstalled = YES;
            break;
        }
    }

    if (!isAppInstalled) {
        UIApplication *app = [UIApplication sharedApplication];
        [app terminateWithSuccess];
    }
}

static void SpringBoardLockStatusChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    HUDMenuRootViewController *rootViewController = (__bridge HUDMenuRootViewController *)observer;
    NSString *lockState = (__bridge NSString *)name;
    if ([lockState isEqualToString:@NOTIFY_UI_LOCKSTATE]) {
        mach_port_t sbsPort = SBSSpringBoardServerPort();
        
        if (sbsPort == MACH_PORT_NULL)
            return;
        
        BOOL isLocked;
        BOOL isPasscodeSet;
        SBGetScreenLockStatus(sbsPort, &isLocked, &isPasscodeSet);

        if (!isLocked) {
            [rootViewController.view setHidden:NO];
        } else {
            [rootViewController.view setHidden:YES];
        }
    }
}
#endif

CGFloat isWidth = 0;
CGFloat isHeight = 0;

@interface HUDMenuRootViewController (Troll)
- (void)updateOrientation:(UIInterfaceOrientation)orientation animateWithDuration:(NSTimeInterval)duration;
@end

@implementation HUDMenuRootViewController {
#if !NO_TROLL
    FBSOrientationObserver *_orientationObserver;
#endif
    UIInterfaceOrientation _orientation;
}

- (void)registerNotifications {
#if !NO_TROLL
    CFNotificationCenterRef darwinCenter = CFNotificationCenterGetDarwinNotifyCenter();
    CFNotificationCenterAddObserver(
        darwinCenter,
        (__bridge const void *)self,
        LaunchServicesApplicationStateChanged,
        CFSTR(NOTIFY_LS_APP_CHANGED),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
    CFNotificationCenterAddObserver(
        darwinCenter,
        (__bridge const void *)self,
        SpringBoardLockStatusChanged,
        CFSTR(NOTIFY_UI_LOCKSTATE),
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
#endif
}

+ (BOOL)passthroughMode {
    return NO;
}

- (BOOL)usesRotation {
    return YES;// 跟随旋转
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self registerNotifications];
#if !NO_TROLL
        _orientationObserver = [[objc_getClass("FBSOrientationObserver") alloc] init];
        __weak HUDMenuRootViewController *weakSelf = self;
        [_orientationObserver setHandler:^(FBSOrientationUpdate *orientationUpdate) {
            HUDMenuRootViewController *strongSelf = weakSelf;
            dispatch_async(dispatch_get_main_queue(), ^{
                [strongSelf updateOrientation:(UIInterfaceOrientation)orientationUpdate.orientation animateWithDuration:orientationUpdate.duration];
            });
        }];
#endif
    }
    return self;
}

- (void)dealloc {
#if !NO_TROLL
    [_orientationObserver invalidate];
#endif
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.userInteractionEnabled = YES;
    HUDMenuWindow *menuWindow = (HUDMenuWindow *)self.view.window;
    [menuWindow showBallView:YES]; // 显示悬浮球
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    HUDMenuWindow *menuWindow = (HUDMenuWindow *)self.view.window;
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:menuWindow];
    
    if (CGRectContainsPoint(menuWindow.ballView.frame, location) && !menuWindow.ballView.hidden) return;
    
    // 正常处理菜单触摸
    NSLog(@"[8888]: 菜单触摸开始: (%.1f, %.1f)", location.x, location.y);
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {

}

- (CGPoint)correctTouchPoint:(CGPoint)point forOrientation:(UIInterfaceOrientation)orientation {
    CGSize viewSize = self.view.bounds.size;
    switch (orientation) {
        case UIInterfaceOrientationLandscapeLeft:
            return CGPointMake(point.y, viewSize.width - point.x);
        case UIInterfaceOrientationLandscapeRight:
            return CGPointMake(viewSize.height - point.y, point.x);
        case UIInterfaceOrientationPortraitUpsideDown:
            return CGPointMake(viewSize.width - point.x, viewSize.height - point.y);
        default:
            return point;
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    notify_post(NOTIFY_LAUNCHED_HUD);
}

- (void)viewSafeAreaInsetsDidChange {
    [super viewSafeAreaInsetsDidChange];
    [self updateViewConstraints];
}

- (void)updateViewConstraints {
    [super updateViewConstraints];
}

@end

#if !NO_TROLL
@implementation HUDMenuRootViewController (Troll)
- (void)updateOrientation:(UIInterfaceOrientation)orientation animateWithDuration:(NSTimeInterval)duration {
    CGSize screenSize = [UIScreen mainScreen].bounds.size;
    UIEdgeInsets safeAreaInsets = self.view.safeAreaInsets;
    CGFloat safeWidth = screenSize.width - safeAreaInsets.left - safeAreaInsets.right;
    CGFloat safeHeight = screenSize.height - safeAreaInsets.top - safeAreaInsets.bottom;

    BOOL isLandscape = UIInterfaceOrientationIsLandscape(orientation);
    isWidth = isLandscape ? MAX(safeWidth, safeHeight) : MIN(safeWidth, safeHeight);
    isHeight = isLandscape ? MIN(safeWidth, safeHeight) : MAX(safeWidth, safeHeight);

    CGAffineTransform transform;
    switch (orientation) {
        case UIInterfaceOrientationPortraitUpsideDown:
            transform = CGAffineTransformMakeRotation(M_PI);
            break;
        case UIInterfaceOrientationLandscapeLeft:
            transform = CGAffineTransformMakeRotation(-M_PI_2);
            break;
        case UIInterfaceOrientationLandscapeRight:
            transform = CGAffineTransformMakeRotation(M_PI_2);
            break;
        default:
            transform = CGAffineTransformIdentity;
            break;
    }

    if (orientation == _orientation) {
        [self.view setNeedsUpdateConstraints];
        return;
    }

    _orientation = orientation;
    CGRect newBounds = CGRectMake(0, 0, isWidth, isHeight);
    [UIView animateWithDuration:duration animations:^{
        self.view.transform = transform;
        self.view.bounds = newBounds;
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        [self.view setNeedsUpdateConstraints];
    }];
    HUDMenuWindow *menuWindow = (HUDMenuWindow *)self.view.window;
    [menuWindow.ballView updateOrientation:orientation];
    [menuWindow adjustBallPositionForRotation];
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

@end

#else
@implementation HUDMenuRootViewController (NoTroll)
- (UIModalPresentationStyle)modalPresentationStyle { return UIModalPresentationOverFullScreen; }
- (UIModalTransitionStyle)modalTransitionStyle { return UIModalTransitionStyleCrossDissolve; }
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator {
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    __weak typeof(self) weakSelf = self;
    [coordinator animateAlongsideTransition:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf.view setNeedsUpdateConstraints];
        [strongSelf.view setHidden:YES];
    } completion:^(id<UIViewControllerTransitionCoordinatorContext>  _Nonnull context) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        [strongSelf.view setHidden:NO];
        [strongSelf adjustFloatBallPosition];
    }];
}
@end
#endif
