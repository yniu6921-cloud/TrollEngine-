//
//  HUDMenuRootViewController.h
//  YuanBao
//
//  Created by 特特 on 2025/4/8.
//  Copyright © 2025 Mr_Laote. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HUDMenuRootViewController : UIViewController
+ (BOOL)passthroughMode;
@end

NS_ASSUME_NONNULL_END
